from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, usr, pss):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = usr
        PASS = pss
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31703
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        try:
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
            self.database = self.client['%s' % (DB)]
            self.collection = self.database['%s' % (COL)]
        except Exception as e:
            print(f"Error connecting to MongoDB: {e}")
            return None
            
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            inserted = self.collection.insert_one(data)  # data should be dictionary       
            return True
        else:
            return False
            
    def read(self, document_id = ""):
        try:
         # Find the document by its _id
            if document_id == "":  
                found_document = self.collection.find()
                
            else :
                found_document = self.collection.find(document_id)
         
            return found_document
         
        except Exception as e:
            print(f"Error reading document: {e}")
            return None
    
    #Method for updating a specific file
    def update(self, query, new_values):
        try:
            #tries to update the specified file
            self.collection.update_one(query, new_values)
            
            return True

        except Exception as e:
            print(f"Error reading document: {e}")
            return False
    
    #Method for deletion of a query. returns true false if the method works
    def remove(self, query):
        try:
            #trues to remove the queried file
            self.collection.delete_one(query)

            return True

        except Exception as e:
            print(f"Error reading document: {e}")
            return False
